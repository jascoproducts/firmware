# DISCLAIMER:
The software is provided "as is" to provide our customers the ability to update our products. Jasco does not offer any express or implied warranty of any kind when using these files, including, but not limited to, warranties of merchantability, noninfringement, or fitness for a particular purpose.<br>
<br>
Jasco does not imply or guarantee that the software provided will meet your requirements or that the operation thereof will be uninterrupted or error-free, or that all errors will be corrected. Jasco does not assume any responsibility for product errors related to the use of the software contained within this repository. Jasco does not offer support on flashing firmware to the devices listed here and are only provided as a courtesy to our customers and the community.

## CONTENTS:
ZWA4013_Enbrighten_58446_1.26.gbl

## Z-WAVE DEVKIT VERSION:


## RELEASE NOTES:
v1.26: LATEST RELEASE FOR MODEL 58446 AS OF 9/25/25

## DATE CODES INSTALLED ON:
N/A

## CHANGELOG:
1. Fixes latching issue
