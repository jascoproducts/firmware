# DISCLAIMER:
The software is provided "as is" to provide our customers the ability to update our products. Jasco does not offer any express or implied warranty of any kind when using these files, including, but not limited to, warranties of merchantability, noninfringement, or fitness for a particular purpose.<br>
<br>
Jasco does not imply or guarantee that the software provided will meet your requirements or that the operation thereof will be uninterrupted or error-free, or that all errors will be corrected. Jasco does not assume any responsibility for product errors related to the use of the software contained within this repository. Jasco does not offer support on flashing firmware to the devices listed here and are only provided as a courtesy to our customers and the community.

## CONTENTS:
ZW1002_Enbrighten-GE_14297_5.51.otz

## Z-WAVE DEVKIT VERSION:
6.82.00

## RELEASE NOTES:
v5.51: SECOND RELEASE FOR MODEL 14297

## DATE CODES INSTALLED ON:
2031 THROUGH PRESENT

## CHANGELOG:
1. S2 implementation<br>
2. Central Scene implementation<br>
3. Remove All ON/OFF<br>
4. Modify parameter 3