# DISCLAIMER:
The software is provided "as is" to provide our customers the ability to update our products. Jasco does not offer any express or implied warranty of any kind when using these files, including, but not limited to, warranties of merchantability, noninfringement, or fitness for a particular purpose.<br>
<br>
Jasco does not imply or guarantee that the software provided will meet your requirements or that the operation thereof will be uninterrupted or error-free, or that all errors will be corrected. Jasco does not assume any responsibility for product errors related to the use of the software contained within this repository. Jasco does not offer support on flashing firmware to the devices listed here and are only provided as a courtesy to our customers and the community.

## CONTENTS:
ZW3004_Enbrighten-GE_14295_5.21.hex

## RELEASE NOTES:
v5.21: ORIGINAL RELEASE FOR MODEL 14295

## DATE CODES INSTALLED ON:
1651 THROUGH 1847

## CHANGELOG:
1. Original Release Firmware