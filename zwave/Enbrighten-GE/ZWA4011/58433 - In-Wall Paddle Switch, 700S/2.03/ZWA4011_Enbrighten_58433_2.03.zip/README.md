# DISCLAIMER:
The software is provided "as is" to provide our customers the ability to update our products. Jasco does not offer any express or implied warranty of any kind when using these files, including, but not limited to, warranties of merchantability, noninfringement, or fitness for a particular purpose.<br>
<br>
Jasco does not imply or guarantee that the software provided will meet your requirements or that the operation thereof will be uninterrupted or error-free, or that all errors will be corrected. Jasco does not assume any responsibility for product errors related to the use of the software contained within this repository. Jasco does not offer support on flashing firmware to the devices listed here and are only provided as a courtesy to our customers and the community.

## CONTENTS:
ZWA4011_Enbrighten_58433_2.03.gbl

## Z-WAVE DEVKIT VERSION:
7.21.7

## RELEASE NOTES:
v2.03: LATEST RELEASE FOR MODEL 58433 AS OF 6/10/26

## DATE CODES INSTALLED ON:
N/A

## CHANGELOG:
1. Updated to latest Silicon Labs SDK which fixes offline bugs